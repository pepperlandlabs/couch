#!/bin/bash

while [ 1 ] ; do 
    node lib/apps/bookmark.js > bookmarker.log
    sleep 1
done;