#!/bin/bash

while [ 1 ] ; do 
    redis_server
    sleep 1;
done;