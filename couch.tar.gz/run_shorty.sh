#!/bin/bash

while [ 1 ] ; do 
    node lib/web/shorty.js > shorty.out
    sleep 1
done;