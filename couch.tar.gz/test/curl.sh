
echo "queue"
curl http://localhost:8889/ponorich/queue
echo ""
echo "played"
curl http://localhost:8889/ponorich/played
echo ""
echo "profile"
curl http://localhost:8889/ponorich/profile
echo ""
echo "following"
curl http://localhost:8889/ponorich/following
echo ""
echo "followers"
curl http://localhost:8889/ponorich/followers
echo "share"
curl http://localhost:8889/share/ponorich/cAGABdvv5u8




